# Cores (sugestão)
Primária: #7C3AED (roxo)
Secundária: #22D3EE (ciano)
Acento: #F59E0B (âmbar)
Fundo: #0B0F19
Texto: #E5E7EB
