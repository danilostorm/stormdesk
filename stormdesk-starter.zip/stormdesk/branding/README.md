# Branding StormDesk
- `appname.txt`: nome da aplicação (StormDesk).
- `colors.md`: referências de paleta/tema.
- `icons/`: coloque aqui ícones `.ico`/`.icns`/`.png`. Os scripts referenciam estes caminhos.

**Tarefas**:
1) Substituir nome “RustDesk” por “StormDesk” nos manifests e UI.
2) Alterar ícones e splash screens.
3) Ajustar textos de “Sobre” e URLs.
